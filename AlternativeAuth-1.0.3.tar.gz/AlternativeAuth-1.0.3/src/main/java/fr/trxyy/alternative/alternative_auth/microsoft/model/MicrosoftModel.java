package fr.trxyy.alternative.alternative_auth.microsoft.model;

public class MicrosoftModel {
	
	public String access_token;
	public String refresh_token;
	public String user_id;
	public String scope;
	public String token_type;
	public String expires_in;
	public String foci;
	
	public String getAccess_token() {
		return access_token;
	}
	public String getRefresh_token() {
		return refresh_token;
	}
	public String getUser_id() {
		return user_id;
	}
	public String getScope() {
		return scope;
	}
	public String getToken_type() {
		return token_type;
	}
	public String getExpires_in() {
		return expires_in;
	}
	public String getFoci() {
		return foci;
	}
	
}
