package fr.trxyy.alternative.alternative_auth.account;

/**
 * @author Trxyy
 */
public enum AccountType {

	MOJANG, MICROSOFT, OFFLINE,

}
