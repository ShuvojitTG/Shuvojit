package fr.trxyy.alternative.alternative_auth.microsoft.model;

public class MinecraftMicrosoftModel {

	public String username;
	public String access_token;
	public String token_type;
	public long expires_in;

	public String getUsername() {
		return username;
	}

	public String getAccess_token() {
		return access_token;
	}

	public String getToken_type() {
		return token_type;
	}

	public long getExpires_in() {
		return expires_in;
	}

}
