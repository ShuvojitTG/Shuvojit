package fr.trxyy.alternative.alternative_auth.microsoft.model;

public class Xui {
	public String uhs;
	
	public Xui(Xui o) {
		if (o.uhs != null) {
			this.uhs = o.uhs;
		}
	}
	
	public String getUhs() {
		return uhs;
	}
}
